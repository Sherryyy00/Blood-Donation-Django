# Django blood bank management system
